const inputText = document.querySelector(".text");
const btnAdd = document.querySelector(".btn");
const list = document.querySelector(".todo-list");

document.addEventListener("DOMContentLoaded", getLocalTodos);
btnAdd.addEventListener("click", addTodo);
list.addEventListener("click", deleteNotite);

function addTodo(event) {
    event.preventDefault();
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    const newTodo = document.createElement("li");
    newTodo.classList.add("todo-item");
    todoDiv.appendChild(newTodo);
    //adaugam la local storage
    saveLocalTodos(inputText.value);


    const btnCompletat = document.createElement("button");
    btnCompletat.innerHTML = '<i class="fas fa-check-circle"></li>';
    btnCompletat.classList.add("btnComplete");
    todoDiv.appendChild(btnCompletat);


    const btnDel = document.createElement("button");
    btnDel.innerHTML = '<i class=" fas fa-trash"></li>';
    btnDel.classList.add("btnDel");
    todoDiv.appendChild(btnDel);

    list.appendChild(todoDiv);
    inputText.value = "";
}

function deleteNotite(e) {
    const item = e.target;

    if(item.classList[0] === "btnDel") {
        const todo = item.parentElement;
        todo.classList.add("slide");

        removeLocalTodos(todo);
        todo.addEventListener("transitioned", function(){
            todo.remove();
        });
    }

    if(item.classList[0] === "btnComplete"){
        const todo = item.parentElement;
        todo.classList.toggle("completed");
    }
}

function saveLocalTodos(todo) {
    let todos;
    if(localStorage.getItem("todos") === null) {
        todos = [];
    }else {
        todos = JSON.parse(localStorage.getItem("todos"));
    }

    todos.push(todo);
    localStorage.setItem("todos", JSON.stringify(todos));
}

function getLocalTodos() {
    let todos;
    if(localStorage.getItem("todos") === null) {
        todos = [];
    }else{
        todos = JSON.parse(localStorage.getItem("todos"));
    }

    todos.forEach( function(todo) {
        const todoDiv = document.createElement("div");
        todoDiv.classList.add("todo");
        const newTodo = document.createElement("li");
        newTodo.innerText = todo;
        newTodo.classList.add("todo-item");
        todoDiv.appendChild(newTodo);

        const btnCompletat = document.createElement("button");
        btnCompletat.innerHTML = '<i class="fas fa-check-circle"></li>';
        btnCompletat.classList.add("btnComplete");
        todoDiv.appendChild(btnCompletat);

        const btnDel = document.createElement("button");
        btnDel.innerHTML = '<i class="fas fa-trash"></li>';
        btnDel.classList.add("btnDel");
        todoDiv.appendChild(btnDel);
    });
}

function removeLocalTodos(todo) {
    let todos;
    if(localStorage.getItem("todos") === null) {
        todos = [];
    }else {
        todos = JSON.parse(localStorage.getItem("todos"));
    }

    const indexTodo = todo.children[0].innerText;
    todos.splice(todos.indexOf(indexTodo), 1);
    localStorage.setItem("todos", JSON.stringify(todos));
}








